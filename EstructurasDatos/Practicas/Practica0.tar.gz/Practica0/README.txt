Nombre del alumno: Cruz Perez Ramon
Numero de cuenta: 315008148

Observaciones de la practica: Cuando de ejecuta el .sh solo se necesita poner el numero de la
practica, no es necesario poner "PracticaN".
