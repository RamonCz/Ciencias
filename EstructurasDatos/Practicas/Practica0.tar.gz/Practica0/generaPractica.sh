mkdir Practica$1
cd Practica$1
mkdir SRC
mkdir BIN
mkdir DOC
touch README.txt
