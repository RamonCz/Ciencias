mv *.class ./Practica$1/BIN/
javadoc -d ./Practica$1/DOC/-version -author -user *.java
tar -czvf Practica$1.tar.gz Practica$1
