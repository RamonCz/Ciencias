CREATE SCHEMA "fbd2020_2_8148" AUTHORIZATION postgres;

CREATE TABLE "fbd2020_2_8148".chofer (
	num_licencia int NOT NULL GENERATED ALWAYS AS IDENTITY,
	nombre varchar NOT NULL,
	domicilio varchar NOT NULL,
	fechaingreso date NOT NULL,
	fotografia bytea NOT NULL,
	telefono int NOT NULL,
	rfc varchar(13) NULL,
	CONSTRAINT chofer_pk PRIMARY KEY (num_licencia),
	unique (rfc)
);

CREATE TABLE "fbd2020_2_8148".vehiculo (
	num_motor int NOT NULL GENERATED ALWAYS AS IDENTITY,
	rfc varchar(13) NOT NULL,
	num_cilindros int NOT NULL,
	marca varchar NOT NULL,
	num_puertas int NOT NULL,
	modelo varchar NOT NULL,
	llanta_refaccion bool NOT NULL,
	CONSTRAINT vehiculo_pk PRIMARY KEY (num_motor),
	CONSTRAINT vehiculo_fk FOREIGN KEY (rfc) REFERENCES "fbd2020_2_8148".chofer(rfc)
);

CREATE TABLE "fbd2020_2_8148".manejar (
	num_licencia int NOT NULL GENERATED ALWAYS AS IDENTITY,
	num_motor int NOT NULL,
	rfc varchar NOT NULL,
	CONSTRAINT manejar_pk PRIMARY KEY (num_licencia),
	CONSTRAINT manejar_fk FOREIGN KEY (num_motor) REFERENCES "fbd2020_2_8148".vehiculo(num_motor)
);


CREATE TABLE "fbd2020_2_8148".correo (
	num_licencia int NOT NULL GENERATED ALWAYS AS IDENTITY,
	email varchar NOT NULL,
	CONSTRAINT correo_pk PRIMARY KEY (email),
	CONSTRAINT correo_fk FOREIGN KEY (num_licencia) REFERENCES "fbd2020_2_8148".chofer(num_licencia)
);

CREATE TABLE "fbd2020_2_8148".cliente (
	id int NOT NULL  GENERATED ALWAYS AS IDENTITY,
	curp varchar(18) NOT NULL,
	nombre varchar NOT NULL,
	correo varchar NOT NULL,
	facultad varchar NOT NULL,
	telefono int NOT NULL,
	fotografia bytea NOT NULL,
	horaentrada time NOT NULL,
	horasalida time NOT NULL,
	ocupacion varchar NOT NULL,
	CONSTRAINT cliente_pk PRIMARY KEY (curp)
);

CREATE TABLE "fbd2020_2_8148".viaje (
	idviaje int NOT NULL GENERATED ALWAYS AS IDENTITY,
	num_motor int NOT NULL,
	num_licencia int NOT NULL,
	numpasajeros int NOT NULL,
	tiempo time NOT NULL,
	distancia varchar NOT NULL,
	destino varchar NOT NULL,
	en_cu bool NOT NULL,
	curp varchar(18) NOT NULL,
	CONSTRAINT viaje_pk PRIMARY KEY (idviaje),
	CONSTRAINT viaje_fk FOREIGN KEY (num_motor) REFERENCES "fbd2020_2_8148".vehiculo(num_motor),
	CONSTRAINT viaje_fk_1 FOREIGN KEY (num_licencia) REFERENCES "fbd2020_2_8148".chofer(num_licencia),
	CONSTRAINT viaje_fk_2 FOREIGN KEY (curp) REFERENCES "fbd2020_2_8148".cliente(curp)
);
