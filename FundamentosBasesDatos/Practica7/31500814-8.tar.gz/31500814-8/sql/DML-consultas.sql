-- Información completa de los dueños activos en la asociación.
SELECT *
FROM chofer;

-- Los taxis de mas de dos puertas de la marca Nissan que no tengan refacción.
SELECT *
FROM vehiculo
WHERE marca = 'nissan' and llanta_refaccion = true;

-- Nombre, domicilio y numero de licencia de conducir de los choferes y
-- dueños que ingresaron a la asociación durante el año en curso.
SELECT nombre,domicilio,num_licencia
FROM chofer
WHERE fechaingreso < date '2019-12-31';

-- El nombre y teléfono celular de los clientes que son alumnos
-- (solamente alumnos) que no sean sean estudiantes de la
-- facultad de ciencias ni de lafacultad de química.
SELECT nombre,telefono
FROM cliente
WHERE ocupacion = 'alumno' and facultad not in ('ciencias', 'quimica');

-- Los viajes que se hayan completado con mas de dos personas y
-- que su destino fue fuera de la Ciudad Universitaria.
SELECT idviaje
FROM viaje
WHERE numpasajeros > 2 and en_cu = false;
