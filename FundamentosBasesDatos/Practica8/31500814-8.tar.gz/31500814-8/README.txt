Bladimir Zenteno Magaña 315101579
Cruz Perez Ramon 315008148
Paredes Sánchez Jacqueline 315069473
