-- Consulta 1:
create temporary table duenochofer as( -- ya que la usaremos en la consulta 2.
select nombre, chofer.num_licencia, correo.email,modelo
from
vehiculo inner join manejar on vehiculo.rfc =  manejar.rfc -- join con rfc pues si esta el rfc significa que es dueno de ese carro
 inner join chofer  on  manejar.num_licencia = chofer.num_licencia
 inner join correo on chofer.num_licencia = correo.num_licencia
order by chofer.nombre asc);

select * from duenochofer;

-- Consulta 2:
create temporary table tmp as(
select ocupacion, count(ocupacion)
from cliente
group by ocupacion);
with res  (duenoychofer, num)
as(
select 'dueño y chofer', count(num_licencia) from duenochofer)
select * from tmp
union
select * from res;

--consulta 3
select marca, vehiculo.modelo,count(vehiculo.modelo)
from vehiculo
group by marca, vehiculo.modelo
order by marca asc

--consulta 4
select chofer.nombre,viaje.anio,viaje.mes ,count(viaje.anio )
from viaje inner join chofer on chofer.num_licencia = viaje.num_licencia
group by chofer.nombre, viaje.anio, viaje.mes
order by chofer.nombre asc;

--consulta 5
select chofer.nombre,manejar.num_licencia, correo.email, vehiculo.modelo
from
vehiculo inner join manejar on vehiculo.num_motor = manejar.num_motor
inner join chofer on manejar.num_licencia = chofer.num_licencia
inner join correo on chofer.num_licencia = correo.num_licencia
group by manejar.num_licencia,chofer.nombre, correo.email, vehiculo.modelo
order by chofer.nombre asc
