Nombres:                 No. de Cuenta:  Correo-e:
Cruz Perez Ramon ​        315008148        ramoncruz@ciencias.unam.mx
Bladimir Zenteno Magaña ​ 315101579        bladimirzen@ciencias.unam.mx
